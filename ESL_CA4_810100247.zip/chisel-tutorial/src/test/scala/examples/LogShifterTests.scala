// See LICENSE.txt for license details.
package examples

import chisel3.iotesters.PeekPokeTester

class LogShifterTests(c: LogShifter) extends PeekPokeTester(c) {
}

