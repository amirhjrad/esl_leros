package solutions

import chisel3.iotesters.{ChiselFlatSpec, Driver, PeekPokeTester}

class ALUTEST (c: ALU) extends PeekPokeTester(c) {
  var A = rnd.nextInt(1 << c.w)
  var B = rnd.nextInt(1 << c.w)
  var OpCod = 0

  //000
  poke(c.io.A_i, A)
  poke(c.io.B_i, B)
  poke(c.io.OpCode_i, OpCod)
  step(1)
  expect(c.io.Result_o, (A)&((1 << c.w)-1))
  println(peek(c.io.Result_o).toString(16))

  //001
  A = rnd.nextInt(1 << c.w)
  B = rnd.nextInt(1 << c.w)
  OpCod = 1

  poke(c.io.A_i, A)
  poke(c.io.B_i, B)
  poke(c.io.OpCode_i, OpCod)
  step(1)
  expect(c.io.Result_o, (A + B)&((1 << c.w)-1))
  println(peek(c.io.Result_o).toString(16))

  //010
  A = rnd.nextInt(1 << c.w)
  B = rnd.nextInt(1 << c.w)
  OpCod = 2

  poke(c.io.A_i, A)
  poke(c.io.B_i, B)
  poke(c.io.OpCode_i, OpCod)
  step(1)
  expect(c.io.Result_o, (A - B)&((1 << c.w)-1))
  println(peek(c.io.Result_o).toString(16))

  //011
  A = rnd.nextInt(1 << c.w)
  B = rnd.nextInt(1 << c.w)
  OpCod = 3

  poke(c.io.A_i, A)
  poke(c.io.B_i, B)
  poke(c.io.OpCode_i, OpCod)
  step(1)
  expect(c.io.Result_o, (A & B)&((1 << c.w)-1))
  println(peek(c.io.Result_o).toString(16))

  //100
  A = rnd.nextInt(1 << c.w)
  B = rnd.nextInt(1 << c.w)
  OpCod = 4

  poke(c.io.A_i, A)
  poke(c.io.B_i, B)
  poke(c.io.OpCode_i, OpCod)
  step(1)
  expect(c.io.Result_o, (A | B)&((1 << c.w)-1))
  println(peek(c.io.Result_o).toString(16))

  //101
  A = rnd.nextInt(1 << c.w)
  B = rnd.nextInt(1 << c.w)
  OpCod = 5

  poke(c.io.A_i, A)
  poke(c.io.B_i, B)
  poke(c.io.OpCode_i, OpCod)
  step(1)
  expect(c.io.Result_o, (A ^ B)&((1 << c.w)-1))
  println(peek(c.io.Result_o).toString(16))

  //110
  A = rnd.nextInt(1 << c.w)
  B = rnd.nextInt(1 << c.w)
  OpCod = 6

  poke(c.io.A_i, A)
  poke(c.io.B_i, B)
  poke(c.io.OpCode_i, OpCod)
  step(1)
  expect(c.io.Result_o, (B)&((1 << c.w)-1))
  println(peek(c.io.Result_o).toString(16))

  //111
  A = rnd.nextInt(1 << c.w)
  B = rnd.nextInt(1 << c.w)
  OpCod = 7

  poke(c.io.A_i, A)
  poke(c.io.B_i, B)
  poke(c.io.OpCode_i, OpCod)
  step(1)
  expect(c.io.Result_o, (A >> 1)&((1 << c.w)-1))
  println(peek(c.io.Result_o).toString(16))
}
